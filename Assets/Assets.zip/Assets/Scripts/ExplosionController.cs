﻿///----------------------------------------------------------------------------------
///   Source File Name: ExplosionController.cs
///   Author's Name:  Roderick Rodelas
///   Student Number: 100978575
///   Program Description: This controls the player's movement.
///   Date: October 25, 2016
///   Last Modified by: Roderick Rodelas
///   Date last modified: 
///   Revision History: 
///----------------------------------------------------------------------------------

using UnityEngine;
using System.Collections;

public class ExplosionController : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	//destroy game object at the end of animation.
	public void End(){
		Destroy (gameObject);
	}
}
