﻿///----------------------------------------------------------------------------------
///   Source File Name:PlayerCollider.cs
///   Author's Name:  Roderick Rodelas
///   Student Number: 100978575
///   Program Description: This controls the enemy's action.
///   Date: October 25, 2016
///   Last Modified by: Roderick Rodelas
///   Date last modified: October 27, 2016
///   Revision History: added the collision conditions
///----------------------------------------------------------------------------------




using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class PlayerCollider : MonoBehaviour {

	public void OnTriggerEnter2D(Collider2D other){

		if (other.gameObject.tag == "enemyBullet") 
		{
			Player.Instance.Lives -= 1;
			Debug.Log ("Collision with " + other.gameObject.tag);
		} else if (other.gameObject.tag=="enemy") {

			Player.Instance.Lives -= 1;
			Debug.Log ("Collision with " + other.gameObject.tag);

			EnemyController sp = other.gameObject.GetComponent<EnemyController>();
			if (sp != null) {
				//reset enemy
				sp.Reset();
			}
		}
	}
}
