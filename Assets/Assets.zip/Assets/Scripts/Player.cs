﻿///----------------------------------------------------------------------------------
///   Source File Name:
///   Author's Name:  Roderick Rodelas
///   Student Number: 100978575
///   Program Description: This controls the enemy's action.
///   Date: October 26, 2016
///   Last Modified by: Roderick Rodelas
///   Date last modified: 
///   Revision History: 
///----------------------------------------------------------------------------------




using UnityEngine;
using System.Collections;

public class Player {

	    private const string key = "HIGH_SCORE";

	    private int _points = 0;
	    private int _lives = 3;
	    private int _highScore = 0;
	    public HUDController hud;

	    private static Player _instance = null;
	    public static Player Instance{
		    
		        get {
			            if (_instance == null) {
				                _instance = new Player ();
				            }        
			            return _instance;
			        }
		    }

	    private Player(){

		        if (PlayerPrefs.HasKey (key)) {
			            _highScore = PlayerPrefs.GetInt (key);
			        }
		    }

	    public int Points{  
		        get{ return _points; }
		        set{ _points = value; 
			            hud.updatePoints();
						
			            if (value > _highScore) {
				                PlayerPrefs.SetInt (key, value);
				                _highScore = value;
				            }
			        }
		    }

	    public int Lives{
		        get{ return _lives; }
		        set{ _lives = value; 
			            hud.updateLives();
			            if(_lives <= 0){
				            //GameOver
				                hud.GameOver();
				            }
			        }
		    }
		
	    public int HighScore{
		        get{ return _highScore; }

		    }
}
