﻿///----------------------------------------------------------------------------------
///   Source File Name:EnemyController.cs
///   Author's Name:  Roderick Rodelas
///   Student Number: 100978575
///   Program Description: This controls the enemy's action.
///   Date: October 25, 2016
///   Last Modified by: Roderick Rodelas
///   Date last modified: October 27, 2016
///   Revision History: Bullet added for enemies to fire
///----------------------------------------------------------------------------------


using UnityEngine;
using System.Collections;

public class EnemyController : MonoBehaviour {

	[SerializeField]
	private GameObject EnemyBullet;
	[SerializeField]
	private GameObject bulletPos;
	[SerializeField]
	private float speed;
	[SerializeField]
	GameObject explosion = null;

	private Vector2 _currentPosition;
	private Transform _transform = null;

	//Constants
	private const float startPosition = 1.75f;
	private const float resetPosition = -20f;
	private const float minY = -6f;
	private const float maxY = 6f;
	private bool shoot = true; // use for shooting

	// Use this for initialization
	void Start () {
		_transform = gameObject.transform;
		_currentPosition = _transform.position;
		Reset ();
	}

	void FixedUpdate () {


		_currentPosition = _transform.position;

		//move the enemy with the given speed
		_currentPosition -= new Vector2(speed, 0);

		//shoot a bullet
		if (shoot == true) {
			GameObject bullet = (GameObject)Instantiate (EnemyBullet);
			bullet.transform.position = bulletPos.transform.position;
			shoot = false;
		}

		_transform.position = _currentPosition;
		//if enemy goes outside the screen 
		if (_transform.position.x < resetPosition) {
			Reset ();
		}

	}

	//reset the enemy.
	public void Reset(){		 
		float startY = Random.Range (minY, maxY);
		_currentPosition = new Vector2 (startPosition, startY);
		_transform.position = _currentPosition;
		shoot = true;

	}

	public void OnTriggerEnter2D(Collider2D other){
		//show explosion
		GameObject ex = Instantiate (explosion);
		ex.transform.position = transform.position;
		Reset(); //respawn (reset) the enemy
	}	
}
