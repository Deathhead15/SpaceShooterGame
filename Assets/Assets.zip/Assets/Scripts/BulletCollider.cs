﻿///----------------------------------------------------------------------------------
///   Source File Name: 
///   Author's Name:  Roderick Rodelas
///   Student Number: 100978575
///   Program Description: This controls the bullet collision and detection.
///   Date: October 26, 2016
///   Last Modified by: Roderick Rodelas
///   Date last modified: October 26, 2016
///   Revision History: added the collision conditions
///----------------------------------------------------------------------------------



using UnityEngine;
using System.Collections;

public class BulletCollider : MonoBehaviour {


	//destroys game object whenever it collided with enemy or enemy bullets
	public void OnTriggerEnter2D(Collider2D other){

		if (other.gameObject.tag == "enemy") {
			Player.Instance.Points += 10;
			Debug.Log ("Collision with " + other.gameObject.tag);

			EnemyController sp = other.gameObject.GetComponent<EnemyController> ();
			if (sp != null) {					
				//reset enemy
				sp.Reset ();
				//destroy missile
				Destroy (gameObject);
					
			}
		} else if (other.gameObject.tag == "enemyBullet") {
			Destroy (gameObject);
		}
	}
}
