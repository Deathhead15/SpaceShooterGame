﻿///----------------------------------------------------------------------------------
///   Source File Name: ShieldCollideController.cs
///   Author's Name:  Roderick Rodelas
///   Student Number: 100978575
///   Program Description: This controls the player's movement.
///   Date: October 28, 2016
///   Last Modified by: Roderick Rodelas
///   Date last modified: 
///   Revision History: 
///----------------------------------------------------------------------------------

using UnityEngine;
using System.Collections;

public class ShieldCollideController : MonoBehaviour {

	private int shieldLife = 2;  //set shield life for two hits

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void OnTriggerEnter2D(Collider2D other){
		if (other.gameObject.tag == "enemyBullet") {
			shieldLife -= 1;
			Debug.Log ("Collision with " + other.gameObject.tag);
			if (shieldLife == 0) {
				Destroy (gameObject);}
		} else if (other.gameObject.tag == "enemy") {
			shieldLife -= 1;
			Debug.Log ("Collision with " + other.gameObject.tag);
			if (shieldLife == 0) {
				Destroy (gameObject);}
		}			
	}
}
