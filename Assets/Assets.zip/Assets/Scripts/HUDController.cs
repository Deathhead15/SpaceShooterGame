﻿///----------------------------------------------------------------------------------
///   Source File Name:HUDController.cs
///   Author's Name:  Roderick Rodelas
///   Student Number: 100978575
///   Program Description: This controls the player's movement.
///   Date: October 26, 2016
///   Last Modified by: Roderick Rodelas
///   Date last modified: October 27, 2016
///   Revision History: Added enemy, player set active conditions.  - October 26, 2016
/// 					Added powerup and shield conditions. - October 27, 2016
///----------------------------------------------------------------------------------

using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class HUDController : MonoBehaviour {

	[SerializeField]
	Text points = null;

	[SerializeField]
	Text lives = null;

	[SerializeField]
	GameObject player = null;

	[SerializeField]
	GameObject enemy1 = null;

	[SerializeField]
	GameObject enemy2 = null;

	[SerializeField]
	GameObject enemy3 = null;

	[SerializeField]
	GameObject powerUp = null;

	[SerializeField]
	GameObject shield = null;

	[SerializeField]
	Text gameover = null;

	[SerializeField]
	Text highscore = null;

	[SerializeField]
	Text gametitle = null;

	[SerializeField]
	Text instruct = null;

	[SerializeField]
	Text playerScore = null;

	[SerializeField]
	Button resetButton = null;
			
	private int pointsLife = 1000; //condition to trigger additional life
	private int pointsShield = 500; //condition to activate powerup gameobject

	void initiliaze(){
		//initialize the game
		Player.Instance.hud = this;
		points.gameObject.SetActive (false);
		lives.gameObject.SetActive (false);
		player.SetActive (false);
		enemy1.SetActive (false);
		enemy2.SetActive (false);
		enemy3.SetActive (false);
		playerScore.gameObject.SetActive (false);
		instruct.gameObject.SetActive (true);
		gametitle.gameObject.SetActive (true);
		gameover.gameObject.SetActive (false);
		shield.gameObject.SetActive (false);
		powerUp.gameObject.SetActive (false);
		highscore.text = "High Score: " + Player.Instance.HighScore;
		highscore.gameObject.SetActive (true);
		resetButton.gameObject.SetActive (true);
	}

	void Start () {
		initiliaze ();
	}

	    
	void Update () {
	}

	public void updateLives(){
		//this updates player lives and points
		lives.text = "Lives: " + Player.Instance.Lives;
	}

	public void updatePoints(){
		//this update player points
		points.text = "Points: " + Player.Instance.Points;
		//add 1 life for every 1000 score
		if (Player.Instance.Points == pointsLife) {
			Player.Instance.Lives += 1;
			pointsLife += 1000;
		}
		//condition to activate powerup gameobject
		if (Player.Instance.Points == pointsShield) {
			powerUp.gameObject.SetActive (true);
			pointsShield += 500;
		}
	}

	public void GameOver(){
		points.gameObject.SetActive (false);
		lives.gameObject.SetActive (false);
		player.SetActive (false);
		enemy1.SetActive (false);
		enemy2.SetActive (false);
		enemy3.SetActive (false);
		gametitle.gameObject.SetActive (true);
		gameover.gameObject.SetActive (true);
		powerUp.gameObject.SetActive (false);
		playerScore.text = "Score: " + Player.Instance.Points;
		highscore.text = "High Score: " + Player.Instance.HighScore;
		highscore.gameObject.SetActive (true);
		playerScore.gameObject.SetActive (true);
		resetButton.gameObject.SetActive (true);
		Player.Instance.Lives = 3;
		Player.Instance.Points = 0;

	}

	public void ResetGame(){
		points.gameObject.SetActive (true);
		lives.gameObject.SetActive (true);
		player.SetActive (true);
		enemy1.SetActive (true);
		enemy2.SetActive (true);
		enemy3.SetActive (true);
		instruct.gameObject.SetActive (false);
		gametitle.gameObject.SetActive (false);
		gameover.gameObject.SetActive (false);
		powerUp.gameObject.SetActive (false);
		playerScore.gameObject.SetActive (false);
		highscore.gameObject.SetActive (false);
		resetButton.gameObject.SetActive (false);
		Player.Instance.Lives = 3;
		Player.Instance.Points = 0;
	}
}
