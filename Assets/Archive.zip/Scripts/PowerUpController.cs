﻿///----------------------------------------------------------------------------------
///   Source File Name: PowerUpController.cs
///   Author's Name:  Roderick Rodelas
///   Student Number: 100978575
///   Program Description: This controls the player's movement.
///   Date: October 28, 2016
///   Last Modified by: Roderick Rodelas
///   Date last modified: 
///   Revision History: 
///----------------------------------------------------------------------------------

using UnityEngine;
using System.Collections;

public class PowerUpController : MonoBehaviour {


	[SerializeField]
	private GameObject shield;

	[SerializeField]
	private float speed;


	private Vector2 _currentPosition;
	private Transform _transform = null;

	//Constants
	private const float startPosition = 1.75f;
	private const float resetPosition = -20f;
	private const float minY = -6f;
	private const float maxY = 6f;

	// Use this for initialization
	void Start () {
		_transform = gameObject.transform;
		_currentPosition = _transform.position;
		shield.gameObject.SetActive (false); //set the shield inactive 
	}

	void FixedUpdate () {


		_currentPosition = _transform.position;

		//move the powerup with the given speed
		_currentPosition -= new Vector2(speed, 0);
		_transform.position = _currentPosition;

		//if powerup goes outside the screen 
		if (_transform.position.x < resetPosition) {
			Destroy (gameObject);
		}

	}
		

	public void OnTriggerEnter2D(Collider2D other){
		if (other.gameObject.tag == "player") 
		{
			shield.gameObject.SetActive (true); //when it collided with player shield is set to active
			Debug.Log ("Collision with " + other.gameObject.tag);
			Destroy (gameObject); //destroy powerup gameobject.
		}

	}		
}
