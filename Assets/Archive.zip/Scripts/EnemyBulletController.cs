﻿///----------------------------------------------------------------------------------
///   Source File Name:EnemyBulletController.cs
///   Author's Name:  Roderick Rodelas
///   Student Number: 100978575
///   Program Description: This controls the enemy's bullet.
///   Date: October 26, 2016
///   Last Modified by: Roderick Rodelas
///   Date last modified: October 27, 2016
///   Revision History: Update boundary - October 26, 2016
/// 					Added sounds - October 27, 2016
///----------------------------------------------------------------------------------

using UnityEngine;
using System.Collections;

public class EnemyBulletController : MonoBehaviour {


	//bullet speed
	[SerializeField]
	private float speed;

	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void FixedUpdate () {
			Vector2 currentPos = transform.position; //bullet current position

		currentPos -= new Vector2(speed, 0) ; //bullets new position
			transform.position = currentPos;//update bullet position 

			if (transform.position.x <= -20f) {
				Destroy (gameObject);
			}
	}

	//destroys game object whenever it collided with player or player bullets
	public void OnTriggerEnter2D(Collider2D other){
		Destroy (gameObject);
	}	
}
