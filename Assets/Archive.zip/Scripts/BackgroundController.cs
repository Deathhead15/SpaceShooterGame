﻿///----------------------------------------------------------------------------------
///   Source File Name:BackgroundController.cs
///   Author's Name:  Roderick Rodelas
///   Student Number: 100978575
///   Program Description: This controls the player's movement.
///   Date: October 25, 2016
///   Last Modified by: Roderick Rodelas
///   Date last modified: 
///   Revision History: 
///----------------------------------------------------------------------------------

using UnityEngine;
using System.Collections;

public class BackgroundController : MonoBehaviour {

		[SerializeField]
		private float speed;


	    private Transform _transform;
	    private Vector2 _currentPosition;

	    // Use this for initialization
	    void Start () {		    
		        _transform = gameObject.transform; 
		        _currentPosition = _transform.position;
		        Reset ();
		    }
	    
	    // Update is called once per frame
	    void FixedUpdate () {

		        _currentPosition = _transform.position;

		        _currentPosition -= new Vector2 (speed, 0);
		        _transform.position = _currentPosition;

				//if background is at the end
		        if (_currentPosition.x <= -18f) {
			            Reset ();
			        }

		    }
		
		//reset background
	    private void Reset(){		    		    
		        _currentPosition = new Vector2 (0, 0);
		        _transform.position = _currentPosition;		    
		    }		
}
