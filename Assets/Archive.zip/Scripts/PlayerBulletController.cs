﻿///----------------------------------------------------------------------------------
///   Source File Name:
///   Author's Name:  Roderick Rodelas
///   Student Number: 100978575
///   Program Description: This controls the player bullets
///   Date: October 25, 2016
///   Last Modified by: Roderick Rodelas
///   Date last modified: 
///   Revision History: 
///----------------------------------------------------------------------------------




using UnityEngine;
using System.Collections;

public class PlayerBulletController : MonoBehaviour {

	[SerializeField]
	private float speed;


	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void FixedUpdate () {

		Vector2 currentPos = transform.position;

		currentPos = new Vector2 (currentPos.x + speed, currentPos.y);
		transform.position = currentPos;

		if (transform.position.x >= 0.4f) {
			Destroy (gameObject);
		}

	}
}
