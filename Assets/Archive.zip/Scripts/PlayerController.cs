﻿///----------------------------------------------------------------------------------
///   Source File Name:PlayerController.cs
///   Author's Name:  Roderick Rodelas
///   Student Number: 100978575
///   Program Description: This controls the player's movement.
///   Date: October 25, 2016
///   Last Modified by: Roderick Rodelas
///   Date last modified: October 26, 2016
///   Revision History: October 26, 2016 - update boundary controls
///----------------------------------------------------------------------------------




using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {

	[SerializeField]
	private float speed;

	[SerializeField]
	private GameObject PlayerBullet;

	[SerializeField]
	private GameObject bulletPosition;


	private Transform _transform;
	private Vector2 _currentPosition;
	private float _playerInputX;
	private float _playerInputY;


	// Use this for initialization
	void Start () {
		_transform = gameObject.transform;
		_currentPosition = _transform.position;

	}
	    
	// Update is called once per frame
	void FixedUpdate () {
		    
		_playerInputX = Input.GetAxis ("Horizontal");
		_playerInputY = Input.GetAxis ("Vertical");
		_currentPosition = _transform.position;

		//fire bullets
		if (Input.GetKeyDown ("space")) 
		{
			GameObject bullet = (GameObject)Instantiate (PlayerBullet);
			bullet.transform.position = bulletPosition.transform.position;

		}

		//move right
		if (_playerInputX > 0) 
		{
			_currentPosition += new Vector2 (speed, 0);
		}

		//move left
		if (_playerInputX < 0) 
		{
			_currentPosition -= new Vector2 (speed, 0);
		}

		//move up
		if (_playerInputY > 0) 
		{
			_currentPosition += new Vector2 (0, speed);
		}

		//move down
		if (_playerInputY < 0) 
		{
			_currentPosition -= new Vector2 (0, speed);
		}
		//boundary movement for player
		//check's player position on x Axis
		if (_currentPosition.x < -18f) {
			_currentPosition.x = -18f; //if less than the boundary mark, make it the boundary mark
		}
		//check's player position on x Axis
		if (_currentPosition.x > -1f) {
			_currentPosition.x = -1f;  //if greater than the boundary mark, make it the boundary mark
		}
		//check's player position on y Axis
		if (_currentPosition.y < -6f) {
			_currentPosition.y = -6f;  //if less than the boundary mark, make it the boundary mark
		}
		//check's player position on y Axis
		if (_currentPosition.y > 6f) {
			_currentPosition.y = 6f;  //if greater than the boundary mark, make it the boundary mark
		}

		_transform.position = _currentPosition;
	
	}
		
}
